## ------------------------------------------------------------------------
# Simulation setup. Feel free to mess around with these values.
n_ind<-30
n_loci<-100
lambda<-15

# Simulate the total read counts from a Poisson distribution
t_reads<-matrix(rpois(n_ind*n_loci,lambda),n_ind,n_loci)

# Add row names and column names
rownames(t_reads)<-paste("ind",1:n_ind,sep="")
colnames(t_reads)<-paste("loc",1:n_loci,sep="")

# Check out the some of the matrix
t_reads[1:5,1:20]

## ------------------------------------------------------------------------
# Sample allele frequencies for 100 loci from the 5 possible frequencies.
p_freqs<-sample(c(0.025,0.1,0.25,0.4,0.5),100,replace=T)
p_freqs[1:20]
ploidy<-4
error<-0.01

# Simulate genotypes from a binomial distribution
genos<-apply(as.matrix(p_freqs),1, function(x) rbinom(n_ind,ploidy,x))

# Check out a bit of the genotype matrix
genos[1:5,1:20]

r_reads<-matrix(NA,n_ind,n_loci)

for(j in 1:n_loci){
  for(i in 1:n_ind){
    if(genos[i,j]==0){
      r_reads[i,j]<-rbinom(1,t_reads[i,j],error)
    } else if(genos[i,j]==ploidy){
      r_reads[i,j]<-rbinom(1,t_reads[i,j],1-error)
    } else {
      r_reads[i,j]<-rbinom(1,t_reads[i,j],genos[i,j]/ploidy)
    }
  }
}

r_reads[1:5,1:10]

## ----,eval=FALSE---------------------------------------------------------
#  # Default run. At a minimum the function uses the total reads matrix,
#  # the reference reads matrix and the ploidy level. This should only take a couple
#  # of minutes.
#  
#  polyfreqs(t_reads,r_reads,ploidy=4)

## ------------------------------------------------------------------------
itr<-100000
thn<-500
ofile<-"polyfreqs_100k-mcmc.out"

#polyfreqs(t_reads,r_reads,ploidy=4,iter=itr,thin=thn,outfile=ofile)

## ----, fig.width=7-------------------------------------------------------
library(coda)
p_table<-read.table("polyfreqs_100k-mcmc.out",header=T,row.names=1)
p_post<-mcmc(p_table,start=thn,end=itr,thin=thn)

# check that effective sample sizes are greater than 200
sum(effectiveSize(p_post) < 200)

# If any are less than 200, we can see which ones they are
colnames(p_post[,effectiveSize(p_post) < 200])

plot(p_post[,4])

